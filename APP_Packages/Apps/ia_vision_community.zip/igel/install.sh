#!/bin/bash
# For root services:
enable_system_service ia_vision.service