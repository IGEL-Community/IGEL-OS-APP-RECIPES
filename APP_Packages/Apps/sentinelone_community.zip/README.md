THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

# Obtain the SentinelOne installer file

- Recipe tested with `SentinelAgent_linux_x86_64_v26_2_1_24.deb`

- Rename file to `SentinelAgent_linux.deb`

# Notes on installation

https://support.guardz.com/en/articles/10088053-sentinelone-installation-linux

- `sentinelone-postinst.sh` will run the following command to set token value:

```bash linenums="1"
/opt/sentinelone/bin/sentinelctl management token set <token_value>
```
