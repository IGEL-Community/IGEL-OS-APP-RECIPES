#!/bin/bash

enable_system_service jazz-agent.service
enable_system_service jazz-contentng.service