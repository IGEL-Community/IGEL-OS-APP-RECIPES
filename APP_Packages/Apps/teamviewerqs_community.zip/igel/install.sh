#!/bin/bash
enable_system_service teamviewerqs.service