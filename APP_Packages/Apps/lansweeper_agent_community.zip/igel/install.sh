#!/bin/bash
# For root services:
enable_system_service ls-agent.service