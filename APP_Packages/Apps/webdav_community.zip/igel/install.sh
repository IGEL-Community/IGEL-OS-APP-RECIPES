#!/bin/bash
# For root services:
enable_system_service webdav.service