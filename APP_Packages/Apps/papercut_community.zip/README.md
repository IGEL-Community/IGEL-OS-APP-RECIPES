THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

**Note:**

# Papercut - Print Deploy Client

- Download deb file and rename to pc-print-deploy-client.deb

- Current version - pc-print-deploy-client.172.16.3.129.deb

- Java Runtime Environment needs to be installed - https://app.igel.com/java17

# Need to update /wfs/papercut/config/client.conf.toml

- Update this file for your site [Configure the client](https://www.papercut.com/help/manuals/print-deploy/configure/config-the-client/)

- Use UMS files to distribute this file
