#!/bin/bash
# For root services:
enable_system_service papercut.service
# Four user service
enable_user_service com.papercut.PrintDeployClient.desktop