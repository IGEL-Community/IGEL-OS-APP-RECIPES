#!/bin/bash
# For root services:
enable_system_service apache2.service