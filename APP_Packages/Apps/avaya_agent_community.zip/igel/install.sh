#!/bin/bash
# For root services:
enable_system_service avaya_agent.service