#!/bin/bash
# For root services:
enable_system_service vnctask.service