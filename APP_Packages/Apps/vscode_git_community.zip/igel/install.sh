#!/bin/bash
# For root services:
enable_system_service vscode_git.service