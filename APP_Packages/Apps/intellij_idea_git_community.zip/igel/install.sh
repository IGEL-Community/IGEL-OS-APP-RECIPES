#!/bin/bash
# For root services:
enable_system_service intelij_idea_git.service