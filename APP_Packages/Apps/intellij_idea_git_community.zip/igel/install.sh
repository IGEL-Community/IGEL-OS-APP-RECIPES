#!/bin/bash
# For root services:
enable_system_service intellij_idea_git.service