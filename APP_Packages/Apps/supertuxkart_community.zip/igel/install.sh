#!/bin/bash
enable_system_service supertuxkart-server.service
enable_user_service supertuxkart.service
