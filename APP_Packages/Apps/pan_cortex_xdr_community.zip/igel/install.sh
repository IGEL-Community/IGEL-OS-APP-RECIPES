#!/bin/bash

enable_system_service pan_cortex_xdr.service