#!/bin/bash
# For root services:
enable_system_service pulsesecure.service