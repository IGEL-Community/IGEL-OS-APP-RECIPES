#!/bin/bash
# For root services:
enable_system_service f5_vpn.service