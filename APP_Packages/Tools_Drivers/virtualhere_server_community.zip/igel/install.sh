#!/bin/bash
# For root services:
enable_system_service virtualhere_server.service