#!/bin/bash
# For root services:
enable_system_service brother_scanner_brscan4.service