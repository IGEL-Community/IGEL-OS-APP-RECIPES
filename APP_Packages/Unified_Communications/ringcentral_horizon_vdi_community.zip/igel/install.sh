#!/bin/bash
# For root services:
enable_system_service ringcentral_horizon_vdi.service