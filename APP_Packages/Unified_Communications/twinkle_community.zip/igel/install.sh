#!/bin/bash
# For root services:
enable_system_service twinkle.service